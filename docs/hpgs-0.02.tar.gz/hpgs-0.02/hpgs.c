/******************************************************************************
 * hpgs - HP 6xxC Printer GhostScript
 *
 * The HP 6xxC series printers uses the ^[*o-1M command to turn to
 * EconoFast mode. GhostScript (gs) uses the -dDepletion parameter
 * to control this, but it can't send a -1M, only -1.
 * This programs gets the output from gs, find the *o-1d2Q string
 * and translates to *o-1M.
 *
 * Author:	Ricardo Vaz Mannrich (husk-le)
 * 		<mannrich@hotmail.com>
 * Date:	May, 22th 2000.
 *
 * Copyright 2000 Ricardo Vaz Mannrich
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *    GNU General Public License for more details.
 *
 *    Tou should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 ******************************************************************************/
#include <stdio.h>
#include <string.h>

#define VERSION 0.02
#define GS "/usr/bin/gs.default "	// keep the ending space

/*-----------------------------------------------------------------------------
 * Variables
 *----------------------------------------------------------------------------*/
FILE *tmp_in;


/*-----------------------------------------------------------------------------
 * void econo_mode()
 *
 * This converts the input to a econo-mode output.
 *----------------------------------------------------------------------------*/
void econo_mode()
{
	char *in_str="*o-1";
	char pos=0;
	char in_char;
	int i=0;
	
	in_char = fgetc(tmp_in);
	while (!feof(tmp_in)) {
		if (in_char==in_str[pos]) {
			pos++;
		} else
			pos=0;

		fputc(in_char, stdout);
		
		if (in_str[pos]=='\0') {
			in_char = fgetc(tmp_in);
			in_char = fgetc(tmp_in);
			in_char = fgetc(tmp_in);
			
			fputc('M', stdout);
			pos=0;
		}

		in_char = fgetc(tmp_in);
		i++;
	}

	fflush(stdout);
}


/*-----------------------------------------------------------------------------
 * int main(int argc, char **argv)
 *
 * This calls the GhostScript, ant puts its output in a temporary file. This
 * calls the econo_mode() function too.
 *----------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
	int i;
	char cmdbuf[512];
	char *tmpname;
	
	cmdbuf[0] = '\0';

	strcat(cmdbuf, GS);
	
	tmpname=tmpnam(NULL);
	
	for (i=1; i < (argc); i++) {
		if (strncasecmp("-sOutputFile=", argv[i], 13)==0) {
			strcat(cmdbuf, "-sOutputFile=");
			strcat(cmdbuf, tmpname);
		} else 
			strcat(cmdbuf, argv[i]);
		
		strcat(cmdbuf, " ");
	}

	system(cmdbuf);		// call GhostScript

	if (strcmp(argv[1], "-help") == 0) {
		return(0);
	}

	tmp_in = fopen(tmpname, "r");
	
	econo_mode();
	
	remove(tmpname);
}
